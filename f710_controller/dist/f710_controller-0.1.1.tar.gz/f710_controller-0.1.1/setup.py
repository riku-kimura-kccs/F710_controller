# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['f710_controller']

package_data = \
{'': ['*']}

entry_points = \
{'console_scripts': ['f710_controller = controller_for_pix_unit2:main']}

setup_kwargs = {
    'name': 'f710-controller',
    'version': '0.1.1',
    'description': '',
    'long_description': None,
    'author': 'riku-kimura-kccs',
    'author_email': 'riku-kimura@kccs.co.jp',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'entry_points': entry_points,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
